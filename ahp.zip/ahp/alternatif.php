<head>
	<link rel="stylesheet" type="text/css" href="semantic/dist/semantic.min.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<?php 
	include('config.php');
	include('fungsi.php');
	$jenis = 'alternatif';


	// menjalankan perintah delete
	if(isset($_POST['delete'])) {
		$id = $_POST['id'];
		deleteAlternatif($id);
	}

	//mendampatkan data tambah
	if (isset($_POST['tambah'])) {
		$jenis	= $_POST['jenis'];
		$nama 	= $_POST['nama_'];
		$nim	= $_POST['nim_'];
		$prodi	= $_POST['prodi_'];
		$ipk	= $_POST['ipk_'];
		$sks_lulus	= $_POST['sks_'];
		$organisasi_diikuti	= $_POST['organisasi_'];
		$prestasi_dicapai	= $_POST['prestasi_'];
	
		tambahData($nama,$nim,$prodi,$ipk,$sks_lulus,$organisasi_diikuti,$prestasi_dicapai);

		header('Location: '.$jenis.'.php');
	}


	include('navbar.php');

?>

<section class="content container mt-5">

	<h2 class="ui header">Alternatif</h2>
	<!-- Tambah button -->
	<a id="openModalTambah" class="ui right floated primary labeled icon button">
	<i class="plus icon"></i>Tambah
	</a>

	<!-- Modal untuk tambah data alternatif -->
	<div id="myModalTambah" class="modal">
<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card">
        <div class="card-body">
		<button type="button" id="closeModalTambah" class="close ml-0" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      <h2><center>Tambah Alternatif</center></h2>
      <form class="ui form" method="post" action="alternatif.php">
			<div class="field">
			<label>Nama :</label>
			<input type="text" name="nama_" >
			</div>
			<div class="field">
			<label>Nim :</label>
			<input type="number" name="nim_" >
			</div>
			<div class="field">
			<label>Prodi :</label>
			<input type="text" name="prodi_" >
			</div>
			<div class="field">
			<label>IPK :</label>
			<input type="text" name="ipk_" step="0.01">
			</div>
			<div class="field">
			<label>SKS yang dilulusi :</label>
			<input type="number" name="sks_" >
			</div>
			<div class="field">
			<label>Organisasi yang diikuti :</label>
			<input type="number" name="organisasi_" >
			</div>
			<div class="field">
			<label>Prestasi yang dicapai :</label>
			<input type="number" name="prestasi_" >
			</div>
			<input type="hidden" name="jenis" value="<?php echo $jenis?>">
		</div>
		<br>
		<input class="ui green button" type="submit" name="tambah" value="SIMPAN">
	</form>
	  </div>
	  </div>
	</div>
  </div>
  </div>

 <!-- Sebelum tag </body> -->
<script>
  // Ambil elemen tombol "Tambah" dan modal tambah
  const openModalButton = document.getElementById('openModalTambah');
  const modalTambah = document.getElementById('myModalTambah');

  // Tambahkan event listener untuk menampilkan modal saat tombol "Tambah" ditekan
  openModalButton.addEventListener('click', function() {
    modalTambah.style.display = 'block'; // Tampilkan modal
  });

  // Ambil elemen tombol "Tutup" di dalam modal tambah
  const closeModalButton = document.getElementById('closeModalTambah');

  // Tambahkan event listener untuk menutup modal saat tombol "Tutup" ditekan
  closeModalButton.addEventListener('click', function() {
    modalTambah.style.display = 'none'; // Sembunyikan modal
  });
</script>



	<table class="ui celled table">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama</th>
				<th>Nim</th>
				<th>Prodi</th>
				<th>IPK</th>
				<th>sks yang dilulusi</th>
				<th>organisasi yang diikuti</th>
				<th>Prestasi yang dicapai</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>

		<?php
			// Menampilkan list alternatif
			$query = "SELECT * FROM alternatif ORDER BY id";
			$result	= mysqli_query($koneksi, $query);

			$i = 0;
			while ($row = mysqli_fetch_array($result)) {
				$i++;
		?>
			<tr>
				<td><?php echo $i ?></td>
				<td><?php echo $row['Nama'] ?></td>
				<td><?php echo $row['Nim'] ?></td>
				<td><?php echo $row['Prodi'] ?></td>
				<td><?php echo $row['IPK'] ?></td>
				<td><?php echo $row['SKS_lulus'] ?></td>
				<td><?php echo $row['Organisasi_diikuti'] ?></td>
				<td><?php echo $row['Prestasi_dicapai'] ?></td>
				<td class="right aligned collapsing">
					<form method="post" action="alternatif.php">
						<input type="hidden" name="id" value="<?php echo $row['id'] ?>">
						<button type="submit" name="delete" class="ui mini red left labeled icon button"><i class="right remove icon"></i>DELETE</button>
					</form>
				</td>
			</tr>

<?php } ?>
	
	</tbody>
		<tfoot class="full-width">
		</tfoot>
	</table>

	<br>
	<form action="rangking.php" method="post">
    <input type="hidden" name="hapus_rangking" value="hapus">
    <button type="submit" class="ui right labeled icon button" style="float: right; ">
        <i class="right arrow icon"></i>
        Lanjut
    </button>
</form>


	
