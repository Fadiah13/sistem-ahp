<head>
	<link rel="stylesheet" type="text/css" href="semantic/dist/semantic.min.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<?php 
	include('config.php');
	include('fungsi.php');
    include('navbar.php');

    // Setelah data disimpan, hitung perangkingan
    $query = "SELECT * FROM alternatif"; // Ambil semua data alternatif
    $result = mysqli_query($koneksi, $query);

    $dataMahasiswa = [];

    while ($row = mysqli_fetch_array($result)) {
        $dataMahasiswa[] = [
            'nama' => $row['Nama'],
            'ipk' => $row['IPK'],
			'sks_dilulusi' => $row['SKS_lulus'],
			'jumlah_organisasi' => $row['Organisasi_diikuti'],
            'jumlah_prestasi' => $row['Prestasi_dicapai'],
            
        ];
    }

	 // Lakukan perhitungan perangkingan
	 $peringkatMahasiswa = perangkinganMahasiswa($dataMahasiswa);

     // Fungsi untuk melakukan perangkingan

function perangkinganMahasiswa($dataMahasiswa)
{
	// Bobot untuk setiap kriteria
	$bobotIPK = [0.098, 0.254, 0.647]; // IPK (1-2.5 , 2.6-3 , >3)
	$bobotPrestasi = [0.058, 0.230, 0.712]; // Jumlah prestasi (1-2 , 3-5 , >5)
	$bobotOrganisasi = [0.070, 0.206, 0.723]; // Jumlah organisasi (1-2 , 3-5, >5)
	$bobotSKS = [0.071, 0.180, 0.748]; // SKS yang dilulusi (50-70 , 71-90 , >90)

	$rankings = [];

	foreach ($dataMahasiswa as $mahasiswa) {
		$totalBobot = 0;
		

		// Menghitung bobot untuk kriteria IPK
		if ($mahasiswa['ipk'] >= 1 && $mahasiswa['ipk'] <= 2.5) {
			$totalBobot1 = $bobotIPK[0] * 0.409;
		} elseif ($mahasiswa['ipk'] > 2.5 && $mahasiswa['ipk'] <= 3) {
			$totalBobot1 = $bobotIPK[1] * 0.409;
		} elseif ($mahasiswa['ipk'] > 3) {
			$totalBobot1 = $bobotIPK[2] * 0.409;
		}

		// Menghitung Bobot untuk kriteria Jumlah prestasi
		if($mahasiswa['jumlah_prestasi'] == 0){
			$totalBobot2 = 0 * 0.162;
		}elseif ($mahasiswa['jumlah_prestasi'] >= 1 && $mahasiswa['jumlah_prestasi'] <= 2) {
			$totalBobot2 = $bobotPrestasi[0] * 0.162;
		} elseif ($mahasiswa['jumlah_prestasi'] >= 3 && $mahasiswa['jumlah_prestasi'] <= 5) {
			$totalBobot2 = $bobotPrestasi[1] * 0.162;
		} elseif ($mahasiswa['jumlah_prestasi'] > 5) {
			$totalBobot2 = $bobotPrestasi[2] * 0.162;
		}

		// Menghitung Bobot untuk kriteria Jumlah organisasi
		if ($mahasiswa['jumlah_organisasi'] == 0){
			$totalBobot3 = 0 * 0.139;
		}elseif($mahasiswa['jumlah_organisasi'] >= 1 && $mahasiswa['jumlah_organisasi'] <= 2) {
			$totalBobot3 = $bobotOrganisasi[0] * 0.139;
		} elseif ($mahasiswa['jumlah_organisasi'] >= 3 && $mahasiswa['jumlah_organisasi'] <= 5) {
			$totalBobot3 = $bobotOrganisasi[1] * 0.139;
		} elseif ($mahasiswa['jumlah_organisasi'] > 5) {
			$totalBobot3 = $bobotOrganisasi[2] * 0.139;
		}

		// Menghitung Bobot untuk kriteria SKS yang dilulusi
		if ($mahasiswa['sks_dilulusi'] >= 50 && $mahasiswa['sks_dilulusi'] <= 70) {
			$totalBobot4 = $bobotSKS[0] * 0.290;
		} elseif ($mahasiswa['sks_dilulusi'] >= 71 && $mahasiswa['sks_dilulusi'] <= 90) {
			$totalBobot4 = $bobotSKS[1] * 0.290;
		} elseif ($mahasiswa['sks_dilulusi'] > 90) {
			$totalBobot4 = $bobotSKS[2] * 0.290;
		}

		$totalBobot = $totalBobot1 + $totalBobot2 + $totalBobot3 + $totalBobot4;
		if ($totalBobot >= 0.320) {
            $Keterangan = 'Berprestasi';
        } else {
            $Keterangan = 'Kurang Berprestasi';
        }

		// Simpan Bobot total untuk setiap mahasiswa
		$rankings[$mahasiswa['nama']] = [
            'bobot_akhir' => $totalBobot,
            'Keterangan' => $Keterangan,
        ];

	}

	// Melakukan sorting untuk mendapatkan peringkat
	arsort($rankings);

	return $rankings;
}


	 // Simpan hasil perangkingan ke dalam tabel rangking
	foreach ($peringkatMahasiswa as $nama => $dataMahasiswa) {
		$bobot_akhir = $dataMahasiswa['bobot_akhir'];
		$Keterangan = $dataMahasiswa['Keterangan'];
		
		// Tambahkan data peringkat ke tabel rangking
		$query = "INSERT INTO rangking (nama_alternatif, bobot_akhir, Keterangan) VALUES ('$nama', '$bobot_akhir', '$Keterangan')";
		mysqli_query($koneksi, $query);
	}

    
?>
<h2><center>Perangkingan Mahasiswa Berprestasi </center></h2>
<table class="ui celled table">
		<thead>
			<tr>
				<th>Peringkat</th>
				<th>Nama</th>
				<th>Bobot Akhir</th>
				<th>Keterangan</th>
			</tr>
		</thead>
		<tbody>

		<?php
			// Menampilkan list rangking
			$query = "SELECT * FROM rangking ORDER BY id";
			$result	= mysqli_query($koneksi, $query);

			$i = 0;
			while ($row = mysqli_fetch_array($result)) {
				$i++;
		?>
			<tr>
				<td><?php echo $i ?></td>
				<td><?php echo $row['nama_alternatif'] ?></td>
				<td><?php echo $row['bobot_akhir'] ?></td>
				<td><?php echo $row['Keterangan'] ?></td>
				
				</td>
			</tr>

<?php } ?>

<?php
// Jika form untuk menghapus rangking dikirimkan
if (isset($_POST['hapus_rangking']) && $_POST['hapus_rangking'] === 'hapus') {
    include('config.php');

    // Query untuk menghapus data dari tabel rangking
    $query = "DELETE FROM rangking";
    $result = mysqli_query($koneksi, $query);
}
?>







