-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2023 at 08:52 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ahp`
--

-- --------------------------------------------------------

--
-- Table structure for table `alternatif`
--

CREATE TABLE `alternatif` (
  `id` int(100) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `Nim` decimal(15,0) NOT NULL,
  `Prodi` varchar(50) NOT NULL,
  `IPK` float NOT NULL,
  `Organisasi_diikuti` int(5) NOT NULL,
  `Prestasi_dicapai` int(5) NOT NULL,
  `SKS_lulus` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alternatif`
--

INSERT INTO `alternatif` (`id`, `Nama`, `Nim`, `Prodi`, `IPK`, `Organisasi_diikuti`, `Prestasi_dicapai`, `SKS_lulus`) VALUES
(4, 'Rezki', 426242720182, 'Tekom', 3.78, 1, 2, 90),
(5, 'Fadiah', 2897262892, 'PTIK', 3.95, 1, 3, 90),
(6, 'Nurul', 729927920, 'PKK', 3.35, 1, 0, 78),
(7, 'Jariah', 8272892, 'Elektro', 2.46, 2, 0, 67);

-- --------------------------------------------------------

--
-- Table structure for table `kriteria`
--

CREATE TABLE `kriteria` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `Keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kriteria`
--

INSERT INTO `kriteria` (`id`, `nama`, `Keterangan`) VALUES
(1, 'IPK', 'Kriteria IPK lebih penting dari semua kriteria yang ada '),
(2, 'Jumlah Prestasi yang Dicapai', 'Kriteria prestasi yang dicapai Lebih penting dibanding Kriteria Organisasi yang pernah diikuti dan kriteria SKS yang dilulusi'),
(3, 'Jumlah Organisasi yang Diikuti', 'Kriteria organisasi yang diikuti lebih penting dibanding kriteria SKS yang dilulusi'),
(4, 'Jumlah SKS yang dilulusi', 'Kriteria SKS memiliki nilai kepentingan yang paling rendah dari ke tiga kriteria lainnya');

-- --------------------------------------------------------

--
-- Table structure for table `rangking`
--

CREATE TABLE `rangking` (
  `id` int(11) NOT NULL,
  `nama_alternatif` varchar(50) NOT NULL,
  `bobot_akhir` float NOT NULL,
  `Keterangan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alternatif`
--
ALTER TABLE `alternatif`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kriteria`
--
ALTER TABLE `kriteria`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rangking`
--
ALTER TABLE `rangking`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alternatif`
--
ALTER TABLE `alternatif`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `kriteria`
--
ALTER TABLE `kriteria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rangking`
--
ALTER TABLE `rangking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
