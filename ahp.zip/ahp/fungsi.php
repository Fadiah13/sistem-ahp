<?php

// menambah data alternatif
function tambahData($nama,$nim,$prodi,$ipk,$sks_lulus,$organisasi_diikuti,$prestasi_dicapai) {
	include('config.php');

	$query 	= "INSERT INTO alternatif (Nama, Nim, Prodi, IPK, SKS_lulus, Organisasi_diikuti, Prestasi_dicapai) VALUES ('$nama', '$nim', '$prodi', '$ipk', '$sks_lulus', '$organisasi_diikuti', '$prestasi_dicapai')";
	$tambah	= mysqli_query($koneksi, $query);

	if (!$tambah) {
		echo "Gagal menambah data".$tabel;
		exit();
	}
}

//hapus kriteria
function deleteKriteria($id) {
	include('config.php');

	// hapus record dari tabel kriteria
	$query 	= "DELETE FROM kriteria WHERE id=$id";
	mysqli_query($koneksi, $query);

	// hapus record dari tabel pv_kriteria
	$query 	= "DELETE FROM pv_kriteria WHERE id_kriteria=$id";
	mysqli_query($koneksi, $query);

	// hapus record dari tabel pv_alternatif
	$query 	= "DELETE FROM pv_alternatif WHERE id_kriteria=$id";
	mysqli_query($koneksi, $query);

	$query 	= "DELETE FROM perbandingan_kriteria WHERE kriteria1=$id OR kriteria2=$id";
	mysqli_query($koneksi, $query);

	$query 	= "DELETE FROM perbandingan_alternatif WHERE pembanding=$id";
	mysqli_query($koneksi, $query);
}

// hapus alternatif
function deleteAlternatif($id) {
	include('config.php');

	// hapus record dari tabel alternatif
	$query 	= "DELETE FROM alternatif WHERE id=$id";
	mysqli_query($koneksi, $query);
}



?>
