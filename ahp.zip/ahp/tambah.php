<?php
	include('config.php');
	include('fungsi.php');

	$angkaform = 0; // Initialize $angkaform
	$jumlahForm = 0; // Initialize $jumlahForm
	$jenis = 'alternatif';

	// mendapatkan data edit
	if(isset($_GET['jenis'])) {
		$jenis	= $_GET['jenis'];
	}
	//mendampatkan data tambah
	if (isset($_POST['tambah'])) {
		$jenis	= $_POST['jenis'];
		$nama 	= $_POST['nama_'];
		$nim	= $_POST['nim_'];
		$prodi	= $_POST['prodi_'];
		$ipk	= $_POST['ipk_'];
		$sks_lulus	= $_POST['sks_'];
		$organisasi_diikuti	= $_POST['organisasi_'];
		$prestasi_dicapai	= $_POST['prestasi_'];
	
		tambahData($nama,$nim,$prodi,$ipk,$sks_lulus,$organisasi_diikuti,$prestasi_dicapai);

		header('Location: '.$jenis.'.php');
	}

	include('navbar.php');
	
	?> 
<form class="ui form" method="post" action="tambah.php">
	<div class="ui segment">
    <h2>Tambah <?php echo $jenis?></h2>
			<div class="field">
			<label>Nama :</label>
			<input type="text" name="nama_" >
			</div>
			<div class="field">
			<label>Nim :</label>
			<input type="number" name="nim_" >
			</div>
			<div class="field">
			<label>Prodi :</label>
			<input type="text" name="prodi_" >
			</div>
			<div class="field">
			<label>IPK :</label>
			<input type="number" name="ipk_" step="0.01" inputmode="decimal">
			</div>
			<div class="field">
			<label>SKS yang dilulusi :</label>
			<input type="decimal" name="sks_" >
			</div>
			<div class="field">
			<label>Organisasi yang diikuti :</label>
			<input type="number" name="organisasi_" >
			</div>
			<div class="field">
			<label>Prestasi yang dicapai :</label>
			<input type="number" name="prestasi_" >
			</div>
			<input type="hidden" name="jenis" value="<?php echo $jenis?>">
		</div>
		<br>
		<input class="ui green button" type="submit" name="tambah" value="SIMPAN">
	</form>
  </div>
</div>